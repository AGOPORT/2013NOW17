/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pengenkerjadirumah.tenant.domain;

/**
 *
 * @author Dias Nurul Arifin <dias@nsiapay.net>
 */
public class OrderForm {
    
    private String query = "";

    public OrderForm() {
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }
 
}
